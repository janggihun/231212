package com.example.boardex.Controller;


import com.example.boardex.dto.IboardDto;
import com.example.boardex.pasing.Pasing;
import com.example.boardex.service.IboardService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@Slf4j
public class BoardController {

  @Autowired
  IboardService boardService;

  @GetMapping("/board/list")
  public String list(IboardDto iboardDto, Pasing pasing, HttpServletRequest request,HttpSession session) {

    session.setAttribute("pagecheck",request.getParameter("page"));
    //페이지기억



    int page = Integer.parseInt(request.getParameter("page"));

    int realpage = (page - 1) * pasing.getPageSize();
    iboardDto.setPage(realpage); //원하는 페이지를 게시판에 넣어주기,처음이면 1//
    //현재 page 처음이면 page =1

    //게시판에 던저줄 게시물 구하기
    List<IboardDto> iboardList = boardService.search(iboardDto);
    request.setAttribute("iboardList", iboardList);

    // 게시판 밑에 페이징 하기
    int allpost = boardService.allCnt();
    pasing.firstPasing(allpost, page);
    request.setAttribute("setPage", pasing);

    return "board";
  }

  @GetMapping("/board/insert") //게시글 등록하는곳으로 이동
  public String goinsert() {

    return "boardinsert";
  }

  @PostMapping("/board/list/inserting")
  public String boardinsert(IboardDto iboardDto, HttpSession session) {
    String userId = (String) session.getAttribute("mb");
    iboardDto.setIuserId(userId);//id 넣기
    log.info("========{}", iboardDto);
    boardService.insert(iboardDto);
    return "redirect:/board/list?page=1";
  }

  @GetMapping("/board/list/read")
  public String read(IboardDto iboardDto, HttpServletRequest request) {
    log.info("======{}", iboardDto); //글번호

    boardService.upView(iboardDto); //조회수 1 증가
    request.setAttribute("read",boardService.read(iboardDto));
    request.setAttribute("reply",boardService.reply(iboardDto));

log.info("=============={}",boardService.reply(iboardDto));
    return "boardRead";
  }

}
