package com.example.boardex.Controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@Slf4j
public class HomeController {


  @GetMapping("/")
  public String home() {

    return "index";
  }


  @GetMapping("/home/login")
  public String login() {
    return "login";
  }

  @GetMapping("/home/join")
  public String join() {
    return "join";
  }

  @GetMapping("/logout")
  public String logout(HttpServletRequest request) {
    HttpSession session = request.getSession();
    session.invalidate();
    return "redirect:/";
  }

}
