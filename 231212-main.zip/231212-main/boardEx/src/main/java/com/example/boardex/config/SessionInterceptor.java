package com.example.boardex.config;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.AsyncHandlerInterceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
public class SessionInterceptor implements AsyncHandlerInterceptor {//세선겸사 즉 컨트롤러 들어가기전에 하는것

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
//		log.info("================prehandle call uri =={}",request.getRequestURI());
//		//인터셉터를 활용 인증(로그인) 여부판단
//		log.info("======================querystring {}",request.getQueryString());
        HttpSession session = request.getSession();
        System.out.println("prehandle진입");
        if(session.getAttribute("mb")==null) {

//            session.setAttribute("urlPrior_login", request.getRequestURI()+"?"+request.getQueryString());
            log.info("========{}",request.getRequestURI());
//            log.info("=============인터셉트");
            System.out.println("인터샙트발동");
            response.sendRedirect("/");

            return false;
        }
        System.out.println("아이디있음");
        return true; //컨트롤러 진입 허락
    }




}
