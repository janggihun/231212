package com.example.boardex.dao;


import com.example.boardex.dto.IboardDto;
import com.example.boardex.dto.Ireply;
import org.apache.ibatis.annotations.Mapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Mapper
public interface IboardDao {

    int insert(IboardDto iboardDto);//글생성
    
    List<IboardDto> search(IboardDto iboardDto); //게시글 전체정보 ,로그인시

    int allCnt();

    IboardDto read(IboardDto iboardDto); //1개글 불러오기
   List<HashMap> reply(IboardDto iboardDto);//그 글의 댓글도 같이 부르기
  
    IboardDto upView1(IboardDto iboardDto); //조회수 확인
    int upView2(IboardDto iboardDto); //조회수 업+!
    
}
