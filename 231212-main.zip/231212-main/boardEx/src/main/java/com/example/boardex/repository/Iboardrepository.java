package com.example.boardex.repository;


import com.example.boardex.dao.IboardDao;
import com.example.boardex.dto.IboardDto;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;

@Repository
@Slf4j
public class Iboardrepository implements IboardDao {
    @Autowired
    IboardDao iboardDao;


    @Override
    public int insert(IboardDto iboardDto) {

        int result = iboardDao.insert(iboardDto);
        if (result == 1) {

            log.info("==========게시물 삽입 성공");

        } else {

            log.info("==========게시물 삽입 실패");

        }
        return result;
    }

    @Override
    public List<IboardDto> search(IboardDto iboardDto) {

        return iboardDao.search(iboardDto);
    }

    @Override
    public int allCnt() {

        return iboardDao.allCnt();
    }

    @Override
    public IboardDto read(IboardDto iboardDto) {

        return iboardDao.read(iboardDto);
    }

    @Override
    public List<HashMap> reply(IboardDto iboardDto) {
        return iboardDao.reply(iboardDto);
    }

    @Override
    public IboardDto upView1(IboardDto iboardDto) {
        IboardDto i =  iboardDao.upView1(iboardDto);
        int num = i.getIview();
        i.setIview(num+1);
        iboardDao.upView2(i);
      return  null ;
    }

    @Override
    public int upView2(IboardDto iboardDto) {


        return 0;
    }

}
