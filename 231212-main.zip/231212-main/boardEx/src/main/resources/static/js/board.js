



$(function() {
    $('#boardinsert').click(function () {

        location.href = "/board/insert";

    })
})

$(function() {
    $('#goback').click(function () {

        var pagecheck = $('#pagecheck').val()
        location.href = "/board/list?page="+pagecheck;

    })
})




