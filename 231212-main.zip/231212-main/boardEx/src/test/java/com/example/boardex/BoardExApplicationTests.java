package com.example.boardex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardExApplicationTests {

    @Test
    void contextLoads() {
    }

}
