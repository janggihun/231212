package com.example.boardex.Controller;


import com.example.boardex.dto.Ireply;
import com.example.boardex.service.IboardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;

@RestController
@Slf4j
public class BoardRestController {

    @Autowired
    IboardService iboardService;

    @PostMapping("/board/list/reply")
    public  Collection<Ireply> allreply(Ireply ireply){
        log.info("==========={}",ireply);

       List<Ireply> rlist = iboardService.allreply(ireply);

        return rlist;
    }


}
