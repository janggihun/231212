package com.example.boardex.Controller;


import com.example.boardex.dto.MemberDto;
import com.example.boardex.service.MemberService;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.Session;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@Slf4j
public class MemberController {

    @Autowired
    MemberService mSer;

    @PostMapping("/member/join") //회원가입
    public String join(MemberDto memberDto) {
        log.info("============회원가입{}", memberDto);
        MemberDto result = mSer.memberJoin(memberDto);
        log.info("===========회원가입{}", result);
        if (result.getUserId().equals("중복")) {
            return "redirect:/home/join";
        } else {
            return "redirect:/";
        }


    }

    @PostMapping("/member/login") //로그인
    public String login(MemberDto memberDto, RedirectAttributes redirectAttributes,HttpSession session) {
        log.info("============로그인{}", memberDto);

        // memberdto를 db로 보내서 아이디 비번 확인하는 작업 필요함
        MemberDto result = mSer.login(memberDto);
        if (result.getUserId().equals("불일치")) {//불일치
            redirectAttributes.addFlashAttribute("msg","아이디 혹은 비밀번호가 불일치 합니다.");
            return "redirect:/";

        } else {//아이디 비번 일치
          redirectAttributes.addFlashAttribute("msg","로그인 성공");
          session.setAttribute("mb",memberDto.getUserId());
          return "redirect:/board/list?page=1";
        }


    }
}
