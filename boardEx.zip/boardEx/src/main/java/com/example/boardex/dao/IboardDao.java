package com.example.boardex.dao;


import com.example.boardex.dto.IboardDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface IboardDao {

    int insert(IboardDto iboardDto);//글생성
    
    List<IboardDto> search(IboardDto iboardDto); //게시글 전체정보 ,로그인시

    int allCnt();

}
