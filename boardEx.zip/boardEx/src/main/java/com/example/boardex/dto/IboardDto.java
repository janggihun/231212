package com.example.boardex.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Slf4j
public class IboardDto {

    private int ino; //글번호
    private String ititle; //제목
    private String iuserId; //작성자
    private int iview; //조회수
    private String icontents; //내용
    private String iDate;
    private int page; //누른 페이지버튼



}
