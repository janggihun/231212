package com.example.boardex.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ireply {

  private int rCnt; //pk 고유넘버
  private int rNo; // 달린글넘버
  private String rId;
  private String rContents;
  private Date rDate;


}
