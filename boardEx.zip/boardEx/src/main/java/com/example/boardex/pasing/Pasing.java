package com.example.boardex.pasing;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class Pasing {
    private int allPage; //전체 페이지수
    private int allPost; // 전체글수 >>db
    private int page;//현재 페이지
    private int leftpage; //첫번째 페이지
    private int rightPage; // 마지막페이지
    private int pageSize = 10; //페이지 사이즈
    private String showPre; //이전표시
    private String showNext; //다음표시
    List<String> number = new ArrayList<>();

    public void firstPasing(int allPost,int page) {

        this.allPage = (int) (Math.ceil((float) allPost / pageSize));
        this.allPost = allPost;
        this.page = page;
        this.leftpage = ((int)Math.ceil(page/(double)pageSize)-1)*pageSize+1;
        this.rightPage = Math.min((leftpage + pageSize - 1),allPage);




        if (leftpage > 10) {

            this.showPre = "<a href='/board/list?page="+(leftpage-1)+"'>이전</a>"; //첫번째페이지 -1한걸 보여주면됨

        } else {
            this.showPre = "";
        }

        if (Math.ceil((double) allPage / pageSize) == Math.ceil((double)page/pageSize)) {
            this.showNext = "";

        } else {
            this.showNext = "<a href='/board/list?page="+(rightPage+1)+ "'>다음</a>";//마지막페이지 +1한걸 보여주면됨
        }


        for(int i = leftpage; i <=rightPage ; i++){

          number.add("<a href='/board/list?page="+i+"'"+"id="+i+">"+i+"</a>");


        }

    }
}
