package com.example.boardex.repository;


import com.example.boardex.dao.IboardDao;
import com.example.boardex.dto.IboardDto;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Slf4j
public class Iboardrepository implements IboardDao {
    @Autowired
    IboardDao iboardDao;

    @Override
    public int insert(IboardDto iboardDto) {

        int result = iboardDao.insert(iboardDto);
        if(result ==1)  {

            log.info("==========게시물 삽입 성공");
                    
        }else{

            log.info("==========게시물 삽입 실패");
            
        }
        return result;
    }

    @Override
    public List<IboardDto> search(IboardDto iboardDto) {

        return iboardDao.search(iboardDto);
    }

    @Override
    public int allCnt() {

        return iboardDao.allCnt();
    }
}
