package com.example.boardex.repository;


import com.example.boardex.dao.MemberDao;
import com.example.boardex.dto.MemberDto;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class MemberRepository implements MemberDao {

    @Autowired
    MemberDao memberDao;

    @Override
    public int save(MemberDto memberDto) {
        int result = memberDao.save(memberDto);
        return result;
    }

    @Override
    public MemberDto idcheck(MemberDto memberDto) {

        MemberDto result = memberDao.idcheck(memberDto);
        log.info("=========={}", result);

        if (result != null) { //동일아이디 있음 , 아이디중복
            memberDto.setUserId("중복");
            return memberDto;
        } else {
            save(memberDto);//id 저장
            return memberDto;
        }

    }
    @Override
    public MemberDto login(MemberDto memberDto) {
        MemberDto result = memberDao.idcheck(memberDto);
        if (result != null) {
            log.info("===============아이디일치");
            if (memberDto.getUserPw().equals(result.getUserPw())) {
                log.info("===============비밀번호일치");
              return memberDto;
            }

        }
        memberDto.setUserId("불일치");
        return memberDto;
    }

}
