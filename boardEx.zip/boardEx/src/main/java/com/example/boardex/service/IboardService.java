package com.example.boardex.service;


import com.example.boardex.dto.IboardDto;
import com.example.boardex.dto.Ireply;
import com.example.boardex.repository.Iboardrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IboardService {

    @Autowired
    Iboardrepository boardrepository;

    public List<Ireply> allreply(Ireply ireply) {

       return boardrepository.selectreply(ireply);

    }

    public void insert(IboardDto iboardDto) {

        boardrepository.insert(iboardDto);

    }

    public List<IboardDto> search(IboardDto iboardDto) {

        return  boardrepository.search(iboardDto);

    }

    public int allCnt() {

       return boardrepository.allCnt();
    }

    public IboardDto read(IboardDto iboardDto) {


        return boardrepository.read(iboardDto);
    }
    public List<HashMap> reply(IboardDto iboardDto) {


        return  boardrepository.reply(iboardDto);
    }
    public void upView(IboardDto iboardDto){
        boardrepository.upView1(iboardDto);
    }

}
