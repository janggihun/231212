package com.example.boardex.service;


import com.example.boardex.dto.IboardDto;
import com.example.boardex.repository.Iboardrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IboardService {

    @Autowired
    Iboardrepository boardrepository;

    public void insert(IboardDto iboardDto) {

        boardrepository.insert(iboardDto);

    }

    public List<IboardDto> search(IboardDto iboardDto) {



        return  boardrepository.search(iboardDto);
    }

    public int allCnt() {

       return boardrepository.allCnt();
    }
}
