
var userid = '<%=(String)session.getAttribute("mb")%>';

$(function() {
    $('#boardinsert').click(function () {

        location.href = "/board/insert";

    })
})

$(function() {
    $('#goback').click(function () {

        location.href = "/board/list";

    })
})




