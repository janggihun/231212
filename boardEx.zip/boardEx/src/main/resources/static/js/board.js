$(function () {
    $('#boardinsert').click(function () {

        location.href = "/board/insert";

    })
})

$(function () {
    $('#goback').click(function () {

        var pagecheck = $('#pagecheck').val()
        location.href = "/board/list?page=" + pagecheck;

    })
})
// boardread

$(function () {
    $('#reply').click(function () {
        idata = {};
        var rId = document.getElementById('userid').innerText;
        var readIno = document.getElementById('ino').innerText;
        var replyval = $('#replyinput').val()
        idata.rNo = readIno;
        idata.rContents = replyval;
        idata.rId = rId;

        $.ajax({

            method: "post",
            url: "/board/list/reply",
            data: idata,

            success: function (res) {

                $('#hello').load(location.href+' #hello');
            },



        })


    })
})



