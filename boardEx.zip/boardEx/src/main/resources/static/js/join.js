let userId = $('userId').val();
let userPw = $('userPw').val();

$(function() {
    $('#joinButton').click(function () {
        if (userId == '') {
            alert("아이디를 입력해주세요")
            return false
        } else if (userPw == '') {
            alert("패스워드를 입력해주세요")
            return false
        } else {

            alert("성공")
            return document.getElementById('');
        }
    })
})

$(function() {
    $('#joinButton').click(function () {
        console.log("누름")
        location.href = "/login"

    })
})



