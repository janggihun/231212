package com.example.boardex.repository;

import com.example.boardex.dao.IboardDao;
import com.example.boardex.dto.IboardDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Repository;

@SpringBootTest
class IboardrepositoryTest {

    @Autowired
    IboardDao iboardDao;

    @Test
    void insert() {
        for (int i = 0; i < 2000; i++){
            IboardDto j = new IboardDto();

            j.setItitle("test");
            j.setIuserId("테스트작성자");
            j.setIview(10);
            j.setIcontents("test is tost");

            iboardDao.insert(j);
        }

    }


}