package com.example.boardex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardExApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoardExApplication.class, args);
    }

}
