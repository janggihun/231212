package com.example.boardex.Controller;

import com.example.boardex.dto.MemberDto;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(){
        System.out.println("true = " + true);
        return "index";
    }

    @PostMapping("/join") //회원가입
    public String join(MemberDto memberDto){


        return "main";

    }
    @GetMapping("/login")
    public String login(HttpServletRequest request){
        HttpSession session = request.getSession();

        session.setAttribute("mb","무언가있음");
        System.out.println("로그인 완료");
        System.out.println("login = ");


        return "login";
    }
    @GetMapping("/join")
    public String join(){
        System.out.println("join = ");
        return "join";
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request){
        HttpSession session = request.getSession();
        session.invalidate();
        return "join";
    }

}
