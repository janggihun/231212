package com.example.boardex.Controller;


import com.example.boardex.dto.MemberDto;
import com.example.boardex.service.MemberService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j
public class MemberController {

  @Autowired
  MemberService mSer;

  @PostMapping("/member/join") //회원가입
  public String join(MemberDto memberDto) {
    log.info("============{}", memberDto);
    MemberDto result = mSer.memberJoin(memberDto);
    log.info("==========={}", result);
    if (result.getUserId().equals("중복")) {
      return "redirect:/home/join";
    } else {
      return "redirect:/";
    }


  }

  @PostMapping("/member/login") //로그인
  public String login(MemberDto memberDto) {
    log.info("============{}", memberDto);
    return "main";
  }
}
