package com.example.boardex.config;




import ch.qos.logback.core.CoreConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
@Slf4j
public class WebConfig  implements WebMvcConfigurer {

    @Autowired
    SessionInterceptor interceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {

        System.out.println("실행됨");
        registry.addInterceptor(interceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/","/js/**","/css/**","/img/**")
                .excludePathPatterns("/login","/join")
                .excludePathPatterns("/favicon.ico","/error")
                .excludePathPatterns("/board/list");

    }


}
