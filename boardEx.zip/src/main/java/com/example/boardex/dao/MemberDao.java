package com.example.boardex.dao;


import com.example.boardex.dto.MemberDto;

import com.example.boardex.repository.MemberRepsitory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class MemberDao implements MemberRepsitory {

  @Autowired
  MemberRepsitory memberRepsitory;

  @Override
  public int save(MemberDto memberDto) {
    int result = memberRepsitory.save(memberDto);
    return result;
  }

  @Override
  public MemberDto idcheck(MemberDto memberDto) {

    MemberDto result = memberRepsitory.idcheck(memberDto);
    log.info("=========={}", result);

    if (result != null) { //동일아이디 있음 , 아이디중복
      memberDto.setUserId("중복");
      return memberDto;
    } else {
      save(memberDto);//id 저장
      return memberDto;
    }

  }
}
