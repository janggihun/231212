package com.example.boardex.repository;

import com.example.boardex.dto.MemberDto;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface MemberRepsitory {


    MemberDto idcheck(MemberDto memberDto);//id  중복 확인
    int save(MemberDto memberDto); //저장


}
