package com.example.boardex.service;

import com.example.boardex.dao.MemberDao;
import com.example.boardex.dto.MemberDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberService {
  @Autowired
  MemberDao memberDao;
  public MemberDto memberJoin(MemberDto memberDto) {

      MemberDto result = memberDao.idcheck(memberDto); //idcheck후 가입까지

      return result;

  }
}
