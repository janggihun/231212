

function get(a){

    return document.getElementById(a);
}
$(function() {
    $('#login').click(function () {
        console.log("누름")
        location.href = "/login"

    })
})

$(function() {
    $('#join').click(function () {
        console.log("누름")
        location.href = "/join"

    })
})





