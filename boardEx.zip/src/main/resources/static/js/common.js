

function get(a){

    return document.getElementById(a);
}
$(function() {
    $('#login').click(function () {
        console.log("누름")
        location.href = "/home/login"

    })
})

$(function() {
    $('#join').click(function () {
        console.log("누름")
        location.href = "/home/join"

    })
})





